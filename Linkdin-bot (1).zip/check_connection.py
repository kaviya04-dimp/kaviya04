from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def send_message_if_connected(driver, profile_url, message):
    driver.get(profile_url)
    wait = WebDriverWait(driver, 10)

    try:
        message_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Message')]")))
        message_button.click()
        textarea = wait.until(EC.presence_of_element_located((By.XPATH, "//div[@role='textbox']")))
        textarea.send_keys(message)
        send_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Send')]")))
        send_btn.click()
        return True
    except:
        return False
