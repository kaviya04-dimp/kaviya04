from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def send_connection_request(driver, profile_url):
    driver.get(profile_url)
    wait = WebDriverWait(driver, 10)

    try:
        connect_button = wait.until(EC.presence_of_element_located((By.XPATH, "//button[contains(text(), 'Connect')]")))
    except:
        more_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label,'More actions')]")))
        more_button.click()
        connect_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='Connect']/..")))

    connect_button.click()
    send_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Send now']")))
    send_button.click()
