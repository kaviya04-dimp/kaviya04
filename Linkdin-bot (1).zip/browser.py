import undetected_chromedriver as uc

browser = None

def launch_browser():
    global browser
    if browser is None:
        options = uc.ChromeOptions()
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-blink-features=AutomationControlled")
        browser = uc.Chrome(options=options)
    return browser

def close_browser():
    global browser
    if browser:
        browser.quit()
        browser = None
