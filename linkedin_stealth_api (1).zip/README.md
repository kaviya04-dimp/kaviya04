# LinkedIn Stealth Automation API

## Features
- Stealth LinkedIn Login
- Connect to profiles
- Check connection & send message
- Session persistence
- Anti-detection with undetected-chromedriver

## Setup

```bash
git clone <your-repo>
cd linkedin_stealth_api
python -m venv venv
source venv/bin/activate  # or .\venv\Scripts\activate on Windows
pip install -r requirements.txt
```

## Run
```bash
uvicorn app.main:app --reload
```

## API Payloads

### POST /login
```json
{
  "username": "your_email",
  "password": "your_password"
}
```

### POST /connect
```json
{
  "profile_url": "https://www.linkedin.com/in/some-profile/"
}
```

### POST /check_connection
```json
{
  "profile_url": "https://www.linkedin.com/in/some-profile/",
  "message": "Hello from automation!"
}
```

### GET /close
No input.
