# Nothing needed here as closing is done in browser.py
