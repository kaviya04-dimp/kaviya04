from fastapi import FastAPI, HTTPException
from app.browser import launch_browser, close_browser
from app.actions import login, connect, check_connection

app = FastAPI()

@app.post("/login")
def login_route(payload: dict):
    try:
        browser = launch_browser()
        login.perform_login(browser, payload["username"], payload["password"])
        return {"message": "Login successful"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/connect")
def connect_route(payload: dict):
    try:
        browser = launch_browser()
        connect.send_connection_request(browser, payload["profile_url"])
        return {"message": "Connection attempt made"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/check_connection")
def check_connection_route(payload: dict):
    try:
        browser = launch_browser()
        connected = check_connection.send_message_if_connected(
            browser, payload["profile_url"], payload["message"]
        )
        return {"connected": connected}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/close")
def close_session():
    close_browser()
    return {"message": "Browser closed"}
